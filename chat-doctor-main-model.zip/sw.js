const CACHE_NAME = 'chat-doctor-v1';

// Install event: cache the app shell
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('Opened cache and caching app shell');
      // Precaching is less critical with the cache-on-fetch strategy below,
      // but can ensure the core shell is available immediately.
      return cache.addAll([
        '/',
        '/index.html',
      ]);
    })
  );
});

// Fetch event: serve from cache, fallback to network and cache the new response
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then(cachedResponse => {
        // Cache hit - return response
        if (cachedResponse) {
          return cachedResponse;
        }

        // Not in cache - fetch from network
        return fetch(event.request).then(
          networkResponse => {
            // Check if we received a valid response
            if (!networkResponse || networkResponse.status !== 200) {
              return networkResponse;
            }
            
            // We only want to cache assets from our origin or trusted CDNs
            const isCachable = event.request.url.startsWith(self.location.origin) || 
                               event.request.url.startsWith('https://cdn.tailwindcss.com') ||
                               event.request.url.startsWith('https://esm.sh/');
            
            if (isCachable) {
                // Clone the response because it's a one-time-use stream
                const responseToCache = networkResponse.clone();
    
                caches.open(CACHE_NAME)
                  .then(cache => {
                    cache.put(event.request, responseToCache);
                  });
            }

            return networkResponse;
          }
        ).catch(error => {
            console.error('Fetching failed:', error);
            // In a real-world app, you might want to return a fallback offline page here.
        });
      })
  );
});


// Activate event: clean up old caches
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});