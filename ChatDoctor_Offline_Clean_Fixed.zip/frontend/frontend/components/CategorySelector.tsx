import Real from '../../components/CategorySelector';
export default Real;
