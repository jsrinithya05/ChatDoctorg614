
# ChatDoctor Offline (Cleaned)

This build removes all API keys and Gemini services. It is fully offline.

## Structure
- **frontend/** — Vite + React (TypeScript), UI unchanged
- **backend/** — Node + Express; serves offline answers from dataset

## Run
Terminal 1:
```
cd backend
npm install
npm start
```

Terminal 2:
```
cd frontend
npm install
npm run dev
```

Open: http://localhost:5173

## Config
Frontend calls backend at http://localhost:5050 (no env needed).

