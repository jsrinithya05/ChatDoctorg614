import json
import random

# Define topics and domains
topics = {
    "Cardiology": ["high blood pressure", "heart attack", "palpitations", "chest pain"],
    "Neurology": ["migraine", "epilepsy", "stroke", "dizziness"],
    "Endocrinology": ["diabetes", "thyroid disorder", "PCOS", "insulin resistance"],
    "Pulmonology": ["asthma", "pneumonia", "bronchitis", "COPD"],
    "Dermatology": ["acne", "eczema", "hair loss", "rashes"],
    "Gastroenterology": ["ulcer", "IBS", "GERD", "liver problem"],
    "Gynecology": ["menstrual pain", "pregnancy care", "contraception", "PMS"],
    "Mental Health": ["depression", "anxiety", "sleep disorder", "stress"],
    "Orthopedics": ["back pain", "fracture", "arthritis", "joint stiffness"],
    "Infectious Diseases": ["COVID-19", "malaria", "dengue", "flu"]
}

accuracy_levels = ["basic", "moderate", "advanced"]

def generate_doctor_response(topic, category, accuracy):
    base_general = {
        "basic": f"{topic.capitalize()} can be managed with simple lifestyle changes and medical guidance.",
        "moderate": f"For {topic}, maintain a healthy lifestyle, manage symptoms, and follow up regularly with a doctor.",
        "advanced": f"{topic.capitalize()} requires diagnostic evaluation and evidence-based management following clinical protocols."
    }

    base_medical = {
        "basic": f"{topic.capitalize()} involves basic physiological disturbances and general symptomatic care.",
        "moderate": f"Management of {topic} includes targeted diagnosis, pharmacologic intervention, and monitoring for complications.",
        "advanced": f"{topic.capitalize()} has multifactorial pathophysiology; treatment depends on stage, comorbidities, and latest evidence-based guidelines."
    }

    if category == "general":
        return base_general[accuracy]
    else:
        return base_medical[accuracy]

def generate_conversation(topic, category, accuracy):
    turns = random.randint(2, 5)
    dialogue = []

    if category == "general":
        user_starters = [
            f"Doctor, I think I have {topic}. What should I do?",
            f"I’ve been having issues related to {topic}. Please help.",
            f"How can I treat {topic} at home?"
        ]
        doctor_followups = [
            "Try to maintain good habits, rest well, and monitor symptoms.",
            "Avoid self-medication; get proper medical advice if it worsens.",
            "Make sure you follow a balanced diet and avoid known triggers."
        ]
    else:
        user_starters = [
            f"Can you explain the pathophysiology of {topic}?",
            f"What is the diagnostic approach for {topic}?",
            f"How is {topic} managed clinically?"
        ]
        doctor_followups = [
            "It depends on patient history, lab tests, and imaging.",
            "Clinical management is usually evidence-guided and patient-specific.",
            "Further reading on the topic can improve understanding of underlying mechanisms."
        ]

    dialogue.append({
        "sender": "user" if category == "general" else "student",
        "message": random.choice(user_starters)
    })

    for _ in range(turns - 1):
        dialogue.append({
            "sender": "doctor",
            "message": generate_doctor_response(topic, category, accuracy)
        })
        if random.random() < 0.5:
            dialogue.append({
                "sender": "user" if category == "general" else "student",
                "message": random.choice(doctor_followups)
            })

    return dialogue

def generate_dataset(num_conversations=10000, filename="chatdoctor_dataset_pro.json"):
    data = []
    conversation_id = 1

    for _ in range(num_conversations):
        domain = random.choice(list(topics.keys()))
        topic = random.choice(topics[domain])
        accuracy = random.choice(accuracy_levels)

        # Create both general and medical_student conversations
        for category in ["general", "medical_student"]:
            conversation = {
                "conversation_id": conversation_id,
                "category": category,
                "domain": domain,
                "topic": topic,
                "accuracy_level": accuracy,
                "dialogue": generate_conversation(topic, category, accuracy)
            }
            data.append(conversation)
            conversation_id += 1

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    print(f"✅ ChatDoctor Pro dataset generated successfully! Saved as {filename}")
    print(f"Total conversations: {len(data)}")

if __name__ == "__main__":
    # You can change the number below to 1_000_000 for full dataset
    generate_dataset(10000)
