import Real from '../../components/ChatScreen';
export default Real;
