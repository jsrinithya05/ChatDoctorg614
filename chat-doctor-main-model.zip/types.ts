export enum Role {
  USER = 'user',
  MODEL = 'model',
}

export enum Mode {
  GENERAL = 'general',
  MEDICAL_STUDENT = 'medical_student',
}

export interface Message {
  role: Role;
  content: string;
  imageUrl?: string;
}
