import { Message } from '../types';

/**
 * Offline local service: talks to Node backend at http://localhost:5050
 * No API keys, no external services.
 */
const API_BASE = (import.meta as any).env?.VITE_BACKEND_URL || 'http://localhost:5050';

export async function generateChatResponseStream(messages: Message[], mode: 'general' | 'medical' = 'general') {
  const userMsg = messages.filter(m => m.sender === 'user').slice(-1)[0];
  const payload = { message: userMsg?.text || '', mode };

  try {
    const res = await fetch(`${API_BASE}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Backend error ${res.status}: ${text}`);
    }
    const data = await res.json();
    return {
      text: data.response || "No answer available.",
      citations: [],
      medicalTerms: [],
      meta: data.meta || {}
    };
  } catch (err:any) {
    return {
      text: `Offline backend error: ${err?.message || err}`,
      citations: [],
      medicalTerms: [],
      meta: { error: true }
    };
  }
}

export async function generateImageForPrompt(_prompt: string) {
  // Offline mode: no image generation
  return { url: '', note: 'Image generation not available in offline mode.' };
}
