
import React from 'react';
import { CloseIcon, CloudUploadIcon, KeyIcon, CodeBracketIcon, RocketIcon } from './icons';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const Step = ({ icon, title, children }: { icon: React.ReactNode, title: string, children: React.ReactNode }) => (
    <div className="flex items-start gap-4">
      <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-300">
        {icon}
      </div>
      <div>
        <h3 className="font-semibold text-lg text-gray-800 dark:text-gray-100">{title}</h3>
        <div className="text-gray-600 dark:text-gray-300">{children}</div>
      </div>
    </div>
  );

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 transition-opacity duration-300"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div 
        className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full p-6 sm:p-8 relative transform transition-all duration-300 scale-95 animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors"
          aria-label="Close"
        >
          <CloseIcon />
        </button>
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-gray-100 mb-2">Get Your Public URL</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          Follow these steps to deploy your Chat Doctor and share it with the world.
        </p>
        
        <div className="space-y-6">
          <Step icon={<CloudUploadIcon />} title="1. Choose a Hosting Platform">
            <p>Services like <a href="https://vercel.com" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline font-medium">Vercel</a> or <a href="https://netlify.com" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline font-medium">Netlify</a> are perfect for this and have free plans to get you started.</p>
          </Step>

          <Step icon={<CodeBracketIcon />} title="2. Connect Your Code">
             <p>Sign up on your chosen platform and connect your code repository (e.g., from GitHub) or simply upload this project's folder.</p>
          </Step>

          <Step icon={<KeyIcon />} title="3. Set Your API Key (Crucial!)">
            <div className="border-l-4 border-red-500 pl-4 py-2 bg-red-50 dark:bg-red-900/20 rounded-r-md">
              <p className="font-semibold text-red-800 dark:text-red-200">This is the most important step.</p>
              <p>In your hosting provider's dashboard, find the "Environment Variables" section for your project.</p>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>Create a variable named: <code className="bg-gray-200 dark:bg-gray-700 px-2 py-0.5 rounded text-sm font-mono">API_KEY</code></li>
                <li>Paste your secret Gemini API key as its value.</li>
              </ul>
              <p className="mt-2 text-sm">This keeps your key safe and makes the app work.</p>
            </div>
          </Step>

          <Step icon={<RocketIcon />} title="4. Deploy & Share!">
            <p>Hit the "Deploy" button. Once finished, you'll receive a public URL (like <code className="bg-gray-200 dark:bg-gray-700 px-1.5 py-0.5 rounded text-sm font-mono">my-chat-doctor.vercel.app</code>) that you can share with anyone!</p>
          </Step>
        </div>

        <div className="mt-8 text-right">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-800 transition-transform transform hover:scale-105"
          >
            Got it!
          </button>
        </div>
        <style>{`
          @keyframes scale-in {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
          }
          .animate-scale-in { animation: scale-in 0.2s ease-out forwards; }
        `}</style>
      </div>
    </div>
  );
};

export default ShareModal;
