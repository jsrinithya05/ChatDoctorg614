import React, { useState, useEffect, useRef } from 'react';
import { Message, Role, Mode } from './types';
import { generateResponse, generateWelcomeMessage } from './services/geminiService';
import MessageInput from './components/MessageInput';
import ChatBubble from './components/ChatBubble';
import CoverPage from './components/CoverPage';
import ShareModal from './components/ShareModal';
import { ShareIcon, InstallIcon } from './components/icons';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>(Mode.GENERAL);
  const [showCover, setShowCover] = useState(true);
  const [userAge, setUserAge] = useState<string | null>(null);
  const [userLanguage, setUserLanguage] = useState<string>('English');
  const [userGender, setUserGender] = useState<string>('');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<Event | null>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
        e.preventDefault();
        setInstallPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
        window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = () => {
    if (!installPrompt) return;
    (installPrompt as any).prompt();
    (installPrompt as any).userChoice.then((choiceResult: { outcome: string }) => {
        if (choiceResult.outcome === 'accepted') {
            console.log('User accepted the install prompt');
        } else {
            console.log('User dismissed the install prompt');
        }
        setInstallPrompt(null);
    });
  };

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (!showCover) {
      scrollToBottom();
    }
  }, [messages, showCover]);
  
  const handleStartChat = async (ageCategory: string, language: string, selectedMode: Mode, gender: string) => {
    setIsLoading(true);
    setUserAge(ageCategory);
    setUserLanguage(language);
    setMode(selectedMode);
    setUserGender(gender);
    
    try {
      const welcomeMessageContent = await generateWelcomeMessage(ageCategory, language, selectedMode, gender);
      setMessages([{ role: Role.MODEL, content: welcomeMessageContent }]);
      setShowCover(false);
    } catch(e) {
      const errorMessage = e instanceof Error ? e.message : 'Could not start chat.';
      setError(errorMessage);
      setMessages([{ role: Role.MODEL, content: `Sorry, something went wrong: ${errorMessage}` }]);
      setShowCover(false);
    } finally {
      setIsLoading(false);
    }
  }

  const handleSendMessage = async (userInput: string) => {
    if (userAge === null) return;
    
    setIsLoading(true);
    setError(null);

    const newUserMessage: Message = { role: Role.USER, content: userInput };
    const updatedMessages = [...messages, newUserMessage];
    setMessages(updatedMessages);

    try {
      const history = updatedMessages.slice(0, -1);
      const response = await generateResponse(history, userInput, mode, userAge, userLanguage, userGender);
      const newModelMessage: Message = { 
          role: Role.MODEL, 
          content: response.content,
          imageUrl: response.imageUrl,
      };
      setMessages([...updatedMessages, newModelMessage]);
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(errorMessage);
       const errorModelMessage: Message = { role: Role.MODEL, content: `Sorry, something went wrong: ${errorMessage}` };
      setMessages([...updatedMessages, errorModelMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  if (showCover) {
    return <CoverPage onStart={handleStartChat} isLoading={isLoading} />;
  }

  return (
    <div className="flex flex-col h-screen bg-gray-100 dark:bg-gray-900 font-sans">
      <header className="bg-white dark:bg-gray-800 shadow-md p-4 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
            <h1 className="text-xl md:text-2xl font-bold text-gray-800 dark:text-gray-100">
                Chat Doctor ⚕️
            </h1>
            <div className="flex items-center gap-2">
              {installPrompt && (
                <button
                  onClick={handleInstallClick}
                  className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                  aria-label="Install application"
                >
                  <InstallIcon />
                  Install
                </button>
              )}
              <button
                onClick={() => setIsShareModalOpen(true)}
                className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                aria-label="How to share this application"
              >
                <ShareIcon />
                Share
              </button>
            </div>
        </div>
      </header>
      
      <main className="flex-1 overflow-y-auto p-4 md:p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {messages.map((msg, index) => (
            <ChatBubble key={index} message={msg} />
          ))}
          {isLoading && (
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center animate-pulse"></div>
              <div className="max-w-xl lg:max-w-3xl w-fit p-4 rounded-2xl bg-white dark:bg-gray-800 rounded-bl-none">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                </div>
              </div>
            </div>
          )}
          {error && <p className="text-red-500 text-center">{error}</p>}
          <div ref={chatEndRef} />
        </div>
      </main>

      <MessageInput onSendMessage={handleSendMessage} isLoading={isLoading} />
      <ShareModal isOpen={isShareModalOpen} onClose={() => setIsShareModalOpen(false)} />
    </div>
  );
};

export default App;