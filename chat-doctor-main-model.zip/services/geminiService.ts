import { GoogleGenAI, Type } from "@google/genai";
import { Message, Mode, Role } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const medicalSpecialtiesInfo = `
You are an AI Chat Doctor with expertise in the following medical specialties. Use this information as your primary knowledge base.

# 🩺 Clinical (Non-Surgical) Specialties
These mainly focus on diagnosis, treatment, and prevention without surgery.
- **Internal Medicine**: General adult healthcare, chronic diseases.
- **Pediatrics**: Health of infants, children, adolescents.
- **Family Medicine**: Comprehensive care for all ages.
- **Dermatology**: Skin, hair, and nail conditions.
- **Psychiatry**: Mental health and behavioral disorders.
- **Neurology**: Brain, spinal cord, and nervous system.
- **Cardiology**: Heart and blood vessel diseases.
- **Endocrinology**: Hormones and glands (e.g., diabetes, thyroid).
- **Pulmonology**: Lungs and respiratory system.
- **Nephrology**: Kidneys and urinary system.
- **Gastroenterology**: Digestive system (stomach, intestines, liver).
- **Oncology**: Cancer treatment.
- **Hematology**: Blood disorders.
- **Rheumatology**: Autoimmune and joint diseases.
- **Allergy & Immunology**: Allergies, asthma, immune disorders.

# 🔪 Surgical Specialties
These involve operative treatments.
- **General Surgery**: Abdominal organs, trauma, and emergency surgery.
- **Orthopedic Surgery**: Bones, joints, muscles.
- **Neurosurgery**: Brain, spine, and nervous system surgery.
- **Cardiothoracic Surgery**: Heart, lungs, chest surgery.
- **Vascular Surgery**: Blood vessels outside the heart and brain.
- **Plastic & Reconstructive Surgery**: Cosmetic and reconstructive procedures.
- **Urology**: Urinary tract and male reproductive system.
- **Otolaryngology (ENT)**: Ear, nose, throat, head & neck surgery.
- **Ophthalmology**: Eye surgery and care.
- **Obstetrics & Gynecology (OB-GYN)**: Pregnancy, childbirth, female reproductive system.

# 🧪 Diagnostic & Supportive Specialties
These focus on testing, imaging, and lab work.
- **Radiology**: Medical imaging (X-rays, CT, MRI, ultrasound).
- **Pathology**: Lab testing of tissues, blood, autopsies.
- **Nuclear Medicine**: Radioactive imaging and treatments.
- **Anesthesiology**: Pain management and anesthesia during surgery.
- **Emergency Medicine**: Acute care for urgent conditions.
- **Preventive Medicine & Public Health**: Disease prevention and health promotion.

# 🌍 Other Specialized Fields
- **Sports Medicine**: Injuries and performance optimization in athletes.
- **Geriatrics**: Elderly healthcare.
- **Palliative Medicine**: End-of-life and comfort care.
- **Occupational Medicine**: Work-related health issues.
- **Forensic Medicine**: Legal aspects of medicine.
`;

const getSystemInstruction = (mode: Mode, ageCategory: string, language: string, gender: string): string => {
    let ageDescription = '';
    switch (ageCategory) {
        case 'Child (0-12)':
            ageDescription = 'a child (age 0-12)';
            break;
        case 'Adolescent (13-17)':
            ageDescription = 'an adolescent (age 13-17)';
            break;
        case 'Adult (18-64)':
            ageDescription = 'an adult (age 18-64)';
            break;
        case 'Senior (65+)':
            ageDescription = 'a senior (age 65+)';
            break;
        default:
            ageDescription = 'an adult';
    }
    
    const userInfo = `The user is ${ageDescription} and their gender is ${gender}. You MUST tailor your explanation's complexity, tone, and examples to be appropriate and easily understandable for this specific age group.`;

    if (mode === Mode.MEDICAL_STUDENT) {
        return `You are an expert medical tutor for medical students. 
        ${medicalSpecialtiesInfo}
        1. Provide detailed, accurate, and professional point-by-point explanations based on the specialties listed above.
        2. Use precise medical terminology.
        3. For the user's query, provide a detailed and professional prompt for an image generation model to create a clear, professional-level medical illustration.
        4. ALL RESPONSES MUST BE IN ${language}.
        5. ${userInfo}`;
    }
    // Default to General
    return `You are a helpful AI medical assistant for a general audience.
    ${medicalSpecialtiesInfo}
    1. IMPORTANT: Your primary goal is to provide short and brief explanations based on the specialties listed above. Keep responses concise and to the point.
    2. Explain medical concepts in simple, clear, and easy-to-understand language. Avoid jargon.
    3. For the user's query, provide a simple, descriptive prompt for an image generation model to create a simple and understandable picture.
    4. ALL RESPONSES MUST BE IN ${language}.
    5. ${userInfo}`;
};

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        explanation: {
            type: Type.STRING,
            description: "The text explanation for the user's query.",
        },
        image_prompt: {
            type: Type.STRING,
            description: "A prompt for an image generation model based on the user's query.",
        },
    },
    required: ["explanation", "image_prompt"],
};

export const generateWelcomeMessage = async (ageCategory: string, language: string, mode: Mode, gender: string): Promise<string> => {
    try {
        const persona = mode === Mode.MEDICAL_STUDENT
            ? "an expert medical tutor for a medical student"
            : "a friendly AI doctor for a general user";

        const prompt = `Generate a friendly, welcoming message for a user in the '${ageCategory}' age group who identifies as ${gender}.
        The user's role is: ${mode === Mode.MEDICAL_STUDENT ? 'Medical Student' : 'General User'}.
        The message must be entirely in ${language}. 
        Introduce yourself as the Chat Doctor, acting as ${persona}, and invite them to ask a medical question.`;


        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text;
    } catch (error) {
        console.error("Error generating welcome message:", error);
        // Fallback to a generic English message
        return "Hello! I am your AI Chat Doctor. I was unable to generate a personalized greeting, but I'm here to help. Please ask me anything about medicine.";
    }
};


export const generateResponse = async (history: Message[], newMessage: string, mode: Mode, ageCategory: string, language: string, gender: string): Promise<{ content: string; imageUrl?: string; }> => {
  try {
    const systemInstruction = getSystemInstruction(mode, ageCategory, language, gender);

    // Filter out the initial welcome message from history if it exists
    const chatHistory = history.filter(m => m.role !== Role.MODEL || m.content.includes("Chat Doctor") === false);

    const contents = [
        ...chatHistory.map(msg => ({
            role: msg.role,
            parts: [{ text: msg.content }]
        })),
        {
            role: 'user' as const,
            parts: [{ text: newMessage }]
        }
    ];

    // Step 1: Generate text explanation and image prompt
    const textGenerationResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: contents,
        config: {
            systemInstruction: systemInstruction,
            responseMimeType: "application/json",
            responseSchema: responseSchema,
        }
    });
    
    const jsonResponseText = textGenerationResponse.text.trim();
    const jsonResponse = JSON.parse(jsonResponseText);
    const { explanation, image_prompt } = jsonResponse;

    if (!explanation || !image_prompt) {
        throw new Error("Invalid response structure from text model. Explanation or image prompt missing.");
    }
    
    // Step 2: Generate image
    const imageGenerationResponse = await ai.models.generateImages({
        model: 'imagen-3.0-generate-002',
        prompt: image_prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: '1:1',
        },
    });

    const base64ImageBytes: string = imageGenerationResponse.generatedImages[0].image.imageBytes;
    const imageUrl = `data:image/jpeg;base64,${base64ImageBytes}`;
    
    return { content: explanation, imageUrl };

  } catch (error) {
    console.error("Error generating content:", error);
    let errorMessage = "An unknown error occurred while communicating with the AI.";
     if (error instanceof Error) {
        errorMessage = `An error occurred: ${error.message}. Please check your API key and network connection.`;
    }
    return { content: errorMessage };
  }
};