import React, { useMemo } from 'react';
import { Message, MessageSender, MedicalTerm } from '../types';
import ImageCard from './ImageCard';
import TypingIndicator from './TypingIndicator';

interface MessageProps {
  message: Message;
  searchQuery?: string;
  isLoading?: boolean;
}

const SourceLink: React.FC<{uri: string, title: string}> = ({ uri, title}) => (
    <a 
        href={uri} 
        target="_blank" 
        rel="noopener noreferrer"
        className="block text-xs bg-slate-600 hover:bg-slate-500 transition-colors p-2 rounded-md truncate"
    >
        <span className="font-semibold text-cyan-300">Source:</span> {title || uri}
    </a>
);

// New component to handle text formatting
interface FormattedTextProps {
  text: string;
  terms: MedicalTerm[];
  searchQuery?: string;
}

const escapeRegExp = (string: string) => {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
};

const RichDefinition: React.FC<{ text: string }> = ({ text }) => {
    const parts = text.split(/\*\*(.*?)\*\*/g);
    return (
        <>
            {parts.map((part, index) => {
                if (index % 2 === 1) { // this is the text between ** **
                    return <strong key={index} className="font-semibold text-slate-100">{part}</strong>;
                }
                return <span key={index}>{part}</span>;
            })}
        </>
    );
};

const FormattedText: React.FC<FormattedTextProps> = ({ text, terms, searchQuery }) => {
  const content = useMemo(() => {
      if (!terms || terms.length === 0) {
        if (!searchQuery?.trim()) {
          return text;
        }
        const highlightRegex = new RegExp(`(${escapeRegExp(searchQuery)})`, 'gi');
        const highlightParts = text.split(highlightRegex);
        return highlightParts.map((hPart, hIndex) =>
          hPart.toLowerCase() === searchQuery.toLowerCase() ? (
            <mark key={hIndex} className="bg-yellow-400 text-slate-900 rounded-sm px-0.5">
              {hPart}
            </mark>
          ) : (
            hPart
          )
        );
      }

      const termsMap = new Map(terms.map(t => [t.term.toLowerCase(), t]));
      const regex = new RegExp(`\\b(${terms.map(t => escapeRegExp(t.term)).join('|')})\\b`, 'gi');
      const parts = text.split(regex);

      return parts.map((part, index) => {
        if (!part) return null;
        
        const lowercasedPart = part.toLowerCase();
        if (index % 2 !== 0 && termsMap.has(lowercasedPart)) { // This part is a medical term
          const termData = termsMap.get(lowercasedPart) as MedicalTerm;
          const definition = termData.definition;

          return (
            <span key={index} className="relative group cursor-pointer">
              <strong className="font-semibold text-cyan-300 bg-cyan-900/50 px-1 py-0.5 rounded-md border-b border-dotted border-cyan-400">
                {part}
              </strong>
              {definition && (
                <span className="absolute bottom-full mb-2 w-64 left-1/2 -translate-x-1/2 p-3 text-sm font-medium text-white bg-slate-900 border border-slate-600 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-10">
                  <RichDefinition text={definition} />
                </span>
              )}
            </span>
          );
        } else {
            if (!searchQuery?.trim()) {
                return <span key={index}>{part}</span>;
            }
            const highlightRegex = new RegExp(`(${escapeRegExp(searchQuery)})`, 'gi');
            const highlightParts = part.split(highlightRegex);
            return (
                <span key={index}>
                {highlightParts.map((hPart, hIndex) =>
                    hPart.toLowerCase() === searchQuery.toLowerCase() ? (
                    <mark key={hIndex} className="bg-yellow-400 text-slate-900 rounded-sm px-0.5">
                        {hPart}
                    </mark>
                    ) : (
                    hPart
                    )
                )}
                </span>
            );
        }
      });
  }, [text, terms, searchQuery]);

  return <p className="whitespace-pre-wrap">{content}</p>;
};


const FileIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-slate-300" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
    </svg>
);


const FileAttachmentCard: React.FC<{ attachment: Message['attachment'] }> = ({ attachment }) => {
    if (!attachment) return null;

    return (
        <div className="bg-black/20 p-3 rounded-lg border border-white/10 flex items-center gap-3">
            <FileIcon />
            <div className="flex-1 overflow-hidden">
                <p className="text-sm font-medium text-slate-100 truncate">{attachment.name}</p>
                <p className="text-xs text-slate-400">{attachment.mimeType}</p>
            </div>
        </div>
    );
};


const MessageBubble: React.FC<MessageProps> = ({ message, searchQuery, isLoading }) => {
  const isUser = message.sender === MessageSender.USER;

  const bubbleClasses = isUser
    ? 'bg-cyan-600 self-end rounded-br-none'
    : 'bg-slate-700 self-start rounded-bl-none';
  
  const containerClasses = isUser ? 'justify-end' : 'justify-start';
  
  const isAiPlaceholder = !isUser && !message.text && !message.attachment && isLoading;

  const renderAttachment = () => {
      if (!message.attachment) return null;

      if (message.attachment.mimeType.startsWith('image/')) {
          return <ImageCard imageSrc={message.attachment.dataUrl} sender={message.sender} />;
      }
      return <FileAttachmentCard attachment={message.attachment} />;
  }

  return (
    <div className={`flex ${containerClasses} animate-fade-in-up`}>
      <div className={`flex flex-col p-4 rounded-2xl max-w-xl text-white ${bubbleClasses} ${isAiPlaceholder ? 'space-y-0' : 'space-y-3'}`}>
        {isAiPlaceholder ? (
            <TypingIndicator />
        ) : (
            <>
                {renderAttachment()}

                {message.text && <FormattedText text={message.text} terms={message.medicalTerms || []} searchQuery={searchQuery} />}
                
                {message.sources && message.sources.length > 0 && (
                <div className="pt-3 border-t border-slate-600/70 space-y-2">
                    <h4 className="text-sm font-semibold text-slate-300">Information Sources:</h4>
                    {message.sources.map((source, index) => (
                    <SourceLink key={index} uri={source.uri} title={source.title} />
                    ))}
                </div>
                )}
            </>
        )}
      </div>
    </div>
  );
};

export default React.memo(MessageBubble);