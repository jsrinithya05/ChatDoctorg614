const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const morgan = require('morgan');

const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(cors());
app.use(morgan('dev'));

const datasetPath = path.join(__dirname, 'dataset', 'chatdoctor_dataset.json');
let DATA = [];
function normalize(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}
function jaccard(a, b) {
  const A = new Set(normalize(a).split(' '));
  const B = new Set(normalize(b).split(' '));
  if (A.size === 0 || B.size === 0) return 0;
  let inter = 0;
  for (const t of A) if (B.has(t)) inter++;
  const union = A.size + B.size - inter;
  return inter / union;
}

function bestMatch(query) {
  const q = normalize(query);
  let best = { score: 0, item: null };
  for (const item of DATA) {
    const text = item.question || item.prompt || item.input || '';
    const score = jaccard(q, text);
    if (score > best.score) best = { score, item };
  }
  return best;
}

try {
  const raw = fs.readFileSync(datasetPath, 'utf-8');
  const parsed = JSON.parse(raw);
  if (Array.isArray(parsed)) {
    DATA = parsed;
  } else if (Array.isArray(parsed?.data)) {
    DATA = parsed.data;
  } else {
    DATA = [];
  }
  console.log(`Loaded dataset with ${DATA.length} entries.`);
} catch (e) {
  console.error('Failed to load dataset:', e.message);
}

app.post('/api/chat', (req, res) => {
  const msg = String(req.body?.message || '');
  const { score, item } = bestMatch(msg);
  let response = 'Sorry, I could not find an offline answer for that.';
  if (item) {
    response = item.answer || item.output || item.response || JSON.stringify(item);
  }
  res.json({
    ok: true,
    response,
    meta: { matchScore: score }
  });
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true, datasetEntries: DATA.length });
});

const PORT = process.env.PORT || 5050;
app.listen(PORT, () => {
  console.log(`🚑 ChatDoctor Offline Backend running on http://localhost:${PORT}`);
});
