import Real from '../../components/ImageCard';
export default Real;
