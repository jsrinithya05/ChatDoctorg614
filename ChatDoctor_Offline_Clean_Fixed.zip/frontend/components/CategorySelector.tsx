import React, { useState } from 'react';
import { UserCategory, UserGender } from '../types';

interface CategorySelectorProps {
  onSelect: (category: UserCategory, age: number, gender: UserGender) => void;
}

const UserIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4 text-cyan-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
    </svg>
);

const MedicalIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4 text-cyan-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
    </svg>
);


const CategorySelector: React.FC<CategorySelectorProps> = ({ onSelect }) => {
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<UserGender | null>(null);
  const [error, setError] = useState('');

  const handleSelect = (category: UserCategory) => {
    const parsedAge = parseInt(age, 10);
    const errors: string[] = [];

    if (!age || isNaN(parsedAge) || parsedAge <= 0 || parsedAge > 120) {
      errors.push('a valid age');
    }
    if (!gender) {
        errors.push('a gender');
    }

    if (errors.length > 0) {
        setError(`Please enter ${errors.join(' and ')} to continue.`);
        return;
    }
    
    setError('');
    onSelect(category, parsedAge, gender as UserGender);
  };
  
  return (
    <div className="text-center animate-fade-in">
      <h2 className="text-2xl font-semibold text-slate-200 mb-2">Who are you?</h2>
      <p className="text-slate-400 mb-6">Select a category and provide your details to tailor the responses.</p>
      
      <div className="flex flex-col md:flex-row gap-8 max-w-2xl mx-auto mb-8">
        <div className="flex-1">
          <label htmlFor="age" className="block text-sm font-medium text-slate-300 mb-2">Your Age</label>
          <input
              type="number"
              id="age"
              value={age}
              onChange={(e) => {
                  setAge(e.target.value);
                  if (error) setError('');
              }}
              placeholder="e.g., 25"
              className="w-full bg-slate-700 text-slate-200 rounded-lg py-3 px-4 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all text-center"
              min="1"
              max="120"
          />
        </div>
        <div className="flex-1">
            <label className="block text-sm font-medium text-slate-300 mb-2">Your Gender</label>
            <div className="flex justify-center items-center gap-2 bg-slate-700 rounded-lg p-1 h-[50px]">
                {(Object.values(UserGender) as Array<UserGender>).map((g) => (
                    <button
                    key={g}
                    type="button"
                    onClick={() => {
                        setGender(g);
                        if (error) setError('');
                    }}
                    className={`flex-1 h-full rounded-md text-sm font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-700 focus:ring-cyan-500 ${
                        gender === g
                        ? 'bg-cyan-500 text-white'
                        : 'bg-transparent text-slate-300 hover:bg-slate-600'
                    }`}
                    >
                    {g}
                    </button>
                ))}
            </div>
        </div>
      </div>
      {error && <p className="text-red-400 text-sm mb-6 -mt-4">{error}</p>}


      <div className="flex flex-col md:flex-row gap-8">
        <div
          onClick={() => handleSelect(UserCategory.GENERAL)}
          className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 p-8 rounded-lg w-72 cursor-pointer transition-all duration-300 hover:bg-slate-700 hover:border-cyan-400 hover:scale-105"
        >
          <UserIcon />
          <h3 className="text-xl font-bold text-white">{UserCategory.GENERAL}</h3>
          <p className="text-slate-400 mt-2">Simple, clear explanations for everyday health questions.</p>
        </div>
        <div
          onClick={() => handleSelect(UserCategory.MEDICAL_STUDENT)}
          className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 p-8 rounded-lg w-72 cursor-pointer transition-all duration-300 hover:bg-slate-700 hover:border-cyan-400 hover:scale-105"
        >
          <MedicalIcon />
          <h3 className="text-xl font-bold text-white">{UserCategory.MEDICAL_STUDENT}</h3>
          <p className="text-slate-400 mt-2">In-depth, technical information for medical studies.</p>
        </div>
      </div>
    </div>
  );
};

export default CategorySelector;