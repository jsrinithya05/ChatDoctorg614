export enum UserCategory {
  GENERAL = 'General User',
  MEDICAL_STUDENT = 'Medical Student',
}

export enum UserGender {
  MALE = 'Male',
  FEMALE = 'Female',
  OTHER = 'Prefer not to say',
}

export enum MessageSender {
  USER = 'user',
  AI = 'ai',
}

export enum ConversationStage {
  INITIAL_QUERY = 1,
  CLARIFICATION = 2,
  CONCLUSION = 3,
}

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface MedicalTerm {
  term: string;
  definition: string;
}

export interface Message {
  id: string;
  text: string;
  sender: MessageSender;
  attachment?: {
    dataUrl: string;
    mimeType: string;
    name: string;
  };
  sources?: GroundingSource[];
  medicalTerms?: MedicalTerm[];
}