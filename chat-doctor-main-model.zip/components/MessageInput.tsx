
import React, { useState, useRef, useEffect } from 'react';
import { SendIcon, MicrophoneIcon } from './icons';

interface MessageInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

// Check for SpeechRecognition API
const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
const recognition = SpeechRecognition ? new SpeechRecognition() : null;

if (recognition) {
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = 'en-US';
}

const MessageInput: React.FC<MessageInputProps> = ({ onSendMessage, isLoading }) => {
  const [inputValue, setInputValue] = useState('');
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef(recognition);

  const handleSend = () => {
    if (inputValue.trim() && !isLoading) {
      onSendMessage(inputValue.trim());
      setInputValue('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };
  
  const toggleListen = () => {
    if (!recognitionRef.current) return;
    
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  useEffect(() => {
    const currentRecognition = recognitionRef.current;
    if (!currentRecognition) return;

    currentRecognition.onresult = (event: any) => {
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        }
      }
      
      // Use functional update to avoid stale state issues and append new transcript
      if(finalTranscript) {
        setInputValue(prevValue => (prevValue ? prevValue + ' ' : '') + finalTranscript.trim());
      }
    };
    
    currentRecognition.onend = () => {
        setIsListening(false);
    };

    currentRecognition.onerror = (event: any) => {
      // Gracefully handle common non-critical speech recognition errors.
      if (event.error === 'no-speech' || event.error === 'aborted') {
        // These are not application errors. 'no-speech' means silence was detected.
        // 'aborted' means the user or browser stopped the recognition.
        // The onend event will fire next, which correctly handles UI state.
      } else {
        console.error('Speech recognition error:', event.error);
      }
    };

    // Return a cleanup function to stop recognition when component unmounts.
    return () => {
      if(currentRecognition) {
          try {
            currentRecognition.stop();
          } catch(e) {
            // may already be stopped
          }
      }
    };
  }, []); // Empty dependency array ensures this effect runs only once.


  return (
    <div className="bg-white dark:bg-gray-800 p-4 shadow-md sticky bottom-0">
      <div className="relative max-w-4xl mx-auto">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask the Chat Doctor..."
          className="w-full pl-4 pr-24 py-3 border border-gray-300 dark:border-gray-600 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          disabled={isLoading}
        />
        <div className="absolute inset-y-0 right-0 flex items-center pr-3">
          {recognition && (
            <button
                onClick={toggleListen}
                className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                aria-label={isListening ? 'Stop listening' : 'Start listening'}
                disabled={isLoading}
            >
                <MicrophoneIcon isListening={isListening} />
            </button>
          )}
          <button
            onClick={handleSend}
            disabled={isLoading || !inputValue.trim()}
            className="ml-2 p-2 rounded-full bg-blue-600 text-white hover:bg-blue-700 disabled:bg-blue-300 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            aria-label="Send message"
          >
            <SendIcon />
          </button>
        </div>
      </div>
    </div>
  );
};

export default MessageInput;