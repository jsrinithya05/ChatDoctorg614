ChatDoctor AI — Offline Dataset Integrated (Perfect Run Guide)
==============================================================

What’s included
---------------
- backend/          → Express server (offline), loads dataset and answers chat via /api/chat
- backend/dataset/  → chatdoctor_dataset.json (generated ~20,000 conversations)
- services/         → Frontend services now call the offline backend (no Gemini)
- components/       → UI wired to localService
- package.json      → Vite React app (frontend) at project root

How to run (2 terminals recommended)
------------------------------------
Terminal A — Backend (port 5050):
  cd app_src/backend
  npm install
  npm run dev

You should see:
  ✅ Loaded ChatDoctor dataset: <N> entries
  🚑 ChatDoctor Offline Backend running on http://localhost:5050

Terminal B — Frontend (port 5173):
  cd app_src
  npm install
  npm run dev

Open the URL Vite prints (usually http://localhost:5173).

Configuration
-------------
- The frontend calls the backend at http://localhost:5050 by default.
- To change this, set VITE_BACKEND_URL in a .env file next to app_src/package.json:
    VITE_BACKEND_URL=http://localhost:5051

Testing
-------
- Health check: http://localhost:5050/api/health
- Chat endpoint (POST):
    curl -X POST http://localhost:5050/api/chat -H "Content-Type: application/json"       -d '{"message":"What are symptoms of dengue?"}'

Notes
-----
- No external AI APIs are used. Everything works fully offline.
- You can replace the dataset by dropping a new file at:
    app_src/backend/dataset/chatdoctor_dataset.json
  Then restart the backend.

== Offline Run Guide ==
Backend:
  cd app_src/backend
  npm install
  npm start    # runs on http://localhost:5050

Frontend:
  cd app_src
  npm install
  npm run dev  # opens Vite dev server (default http://localhost:5173)

Environment:
  app_src/.env.local contains:
    VITE_BACKEND_URL=http://localhost:5050
    VITE_MODE=offline
