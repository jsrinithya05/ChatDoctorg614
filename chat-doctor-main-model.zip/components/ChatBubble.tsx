import React from 'react';
import { Message, Role } from '../types';
import { UserIcon, BotIcon } from './icons';
import MarkdownTable from './MarkdownTable';

interface ChatBubbleProps {
  message: Message;
}

const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isUser = message.role === Role.USER;
  const isModel = message.role === Role.MODEL;

  const bubbleClasses = `max-w-xl lg:max-w-3xl w-fit p-4 rounded-2xl ${
    isUser
      ? 'bg-blue-600 text-white rounded-br-none ml-auto'
      : 'bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 rounded-bl-none'
  }`;
  
  const Icon = isUser ? UserIcon : BotIcon;
  const iconBg = isUser ? 'bg-blue-600' : 'bg-indigo-500';

  return (
    <div className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
       <div className={`flex-shrink-0 w-10 h-10 rounded-full ${iconBg} flex items-center justify-center`}>
            <Icon />
       </div>
      <div className={bubbleClasses}>
        {message.imageUrl && (
            <img 
                src={message.imageUrl} 
                alt="AI generated visual aid" 
                className="mb-4 rounded-lg object-cover w-full" 
            />
        )}
        {isModel && message.content.includes('|') ? (
            <MarkdownTable content={message.content} />
        ) : (
            <p className="whitespace-pre-wrap">{message.content}</p>
        )}
      </div>
    </div>
  );
};

export default ChatBubble;