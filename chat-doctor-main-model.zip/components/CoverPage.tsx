import React, { useState } from 'react';
import { Mode } from '../types';

interface CoverPageProps {
  onStart: (ageCategory: string, language: string, mode: Mode, gender: string) => void;
  isLoading: boolean;
}

const languages = [
    { code: 'English', name: 'English' },
    { code: 'Hindi', name: 'हिन्दी' },
    { code: 'Telugu', name: 'తెలుగు' },
    { code: 'Spanish', name: 'Español' },
    { code: 'French', name: 'Français' },
];

const genders = ['Male', 'Female', 'Prefer not to say'];
const ageCategories = ['Child (0-12)', 'Adolescent (13-17)', 'Adult (18-64)', 'Senior (65+)'];

const CoverPage: React.FC<CoverPageProps> = ({ onStart, isLoading }) => {
  const [ageCategory, setAgeCategory] = useState('Adult (18-64)');
  const [language, setLanguage] = useState('English');
  const [mode, setMode] = useState<Mode>(Mode.GENERAL);
  const [gender, setGender] = useState('Prefer not to say');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStart(ageCategory, language, mode, gender);
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-slate-800 p-4 font-sans">
      <div className="w-full max-w-lg bg-white dark:bg-gray-800 p-8 rounded-xl shadow-2xl transform transition-all hover:scale-105 duration-500">
        <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-800 dark:text-gray-100">
                Welcome to Chat Doctor ⚕️
            </h1>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
                Your personal AI medical assistant.
            </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                    I am a...
                </label>
                <div className="grid grid-cols-2 gap-3">
                    <button
                        type="button"
                        onClick={() => setMode(Mode.GENERAL)}
                        className={`w-full py-2 px-4 rounded-lg font-medium text-center transition-colors ${
                            mode === Mode.GENERAL
                                ? 'bg-blue-600 text-white shadow-md ring-2 ring-blue-300'
                                : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
                        }`}
                        aria-pressed={mode === Mode.GENERAL}
                    >
                        General User
                    </button>
                    <button
                        type="button"
                        onClick={() => setMode(Mode.MEDICAL_STUDENT)}
                        className={`w-full py-2 px-4 rounded-lg font-medium text-center transition-colors ${
                            mode === Mode.MEDICAL_STUDENT
                                ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-300'
                                : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
                        }`}
                        aria-pressed={mode === Mode.MEDICAL_STUDENT}
                    >
                        Medical Student
                    </button>
                </div>
            </div>
            
            <div>
                 <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                    Age Group
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {ageCategories.map((age) => (
                         <button
                            key={age}
                            type="button"
                            onClick={() => setAgeCategory(age)}
                            className={`w-full py-2 px-2 text-sm rounded-lg font-medium text-center transition-colors ${
                                ageCategory === age
                                    ? 'bg-blue-600 text-white shadow-md ring-2 ring-blue-300'
                                    : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
                            }`}
                            aria-pressed={ageCategory === age}
                        >
                            {age}
                        </button>
                    ))}
                </div>
            </div>

            <div>
                 <label htmlFor="language" className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
                    Language
                </label>
                <select
                    id="language"
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                >
                    {languages.map(lang => (
                        <option key={lang.code} value={lang.code}>{lang.name}</option>
                    ))}
                </select>
            </div>
            
            <div>
                 <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                    Gender
                </label>
                <div className="grid grid-cols-3 gap-2">
                    {genders.map((g) => (
                         <button
                            key={g}
                            type="button"
                            onClick={() => setGender(g)}
                            className={`w-full py-2 px-2 text-sm rounded-lg font-medium text-center transition-colors ${
                                gender === g
                                    ? 'bg-blue-600 text-white shadow-md ring-2 ring-blue-300'
                                    : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
                            }`}
                            aria-pressed={gender === g}
                        >
                            {g}
                        </button>
                    ))}
                </div>
            </div>

            <div>
                <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full flex justify-center items-center px-4 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-400 disabled:cursor-not-allowed transition-colors"
                >
                    {isLoading ? (
                         <>
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w-org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Personalizing...
                        </>
                    ) : (
                        'Start Chat'
                    )}
                </button>
            </div>
        </form>
      </div>
    </div>
  );
};

export default CoverPage;