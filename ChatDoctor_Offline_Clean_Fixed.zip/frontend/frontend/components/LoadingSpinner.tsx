import Real from '../../components/LoadingSpinner';
export default Real;
