

import React from 'react';
import { MessageSender } from '../types';

interface ImageCardProps {
  imageSrc: string; // Now expecting a full data URL
  sender: MessageSender;
}

const ImageCard: React.FC<ImageCardProps> = ({ imageSrc, sender }) => {
  const caption = sender === MessageSender.USER ? 'Uploaded image.' : 'AI-generated medical illustration.';

  return (
    <div className="bg-black/20 p-2 rounded-lg border border-white/10">
      <img
        src={imageSrc}
        alt={caption}
        className="rounded-md w-full object-contain max-h-80"
      />
      <p className="text-xs text-slate-400 text-center mt-2">{caption}</p>
    </div>
  );
};

export default ImageCard;