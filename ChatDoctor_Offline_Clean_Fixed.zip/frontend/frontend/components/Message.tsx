import Real from '../../components/Message';
export default Real;
