
import React from 'react';

interface MarkdownTableProps {
  content: string;
}

const MarkdownTable: React.FC<MarkdownTableProps> = ({ content }) => {
  const lines = content.split('\n').filter(line => line.trim().startsWith('|'));
  if (lines.length < 2) {
    return <pre className="whitespace-pre-wrap font-sans">{content}</pre>;
  }

  const parseRow = (line: string): string[] => {
    return line.split('|').map(s => s.trim()).slice(1, -1);
  };
  
  const headerLine = lines[0];
  const separatorLine = lines[1];
  const bodyLines = lines.slice(2);

  if (!separatorLine || !separatorLine.includes('---')) {
    return <pre className="whitespace-pre-wrap font-sans">{content}</pre>;
  }

  const headers = parseRow(headerLine);
  const body = bodyLines.map(parseRow);

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead className="bg-gray-50 dark:bg-gray-800">
          <tr>
            {headers.map((header, index) => (
              <th key={index} scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
          {body.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {row.map((cell, cellIndex) => (
                <td key={cellIndex} className="px-6 py-4 whitespace-pre-wrap text-sm text-gray-900 dark:text-gray-100">
                  {cell.split('*').map((part, i) => i % 2 === 1 ? <strong key={i}>{part}</strong> : part)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MarkdownTable;
