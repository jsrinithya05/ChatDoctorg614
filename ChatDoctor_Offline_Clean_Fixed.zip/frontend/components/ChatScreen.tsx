



import React, { useState, useRef, useEffect } from 'react';
import { UserCategory, UserGender, Message, MessageSender, ConversationStage, GroundingSource, MedicalTerm } from '../types';
import { generateChatResponseStream, generateImageForPrompt } from '../services/localService';
import MessageBubble from './Message';
import LoadingSpinner from './LoadingSpinner';

// Add SpeechRecognition to window type to avoid TS errors
// FIX: Define SpeechRecognition interface and constructor for TypeScript to resolve 'Cannot find name' error on line 32.
interface SpeechRecognition extends EventTarget {
    continuous: boolean;
    interimResults: boolean;
    lang: string;
    onend: () => void;
    onerror: (event: any) => void;
    onresult: (event: any) => void;
    onstart: () => void;
    start: () => void;
    stop: () => void;
}

declare global {
    interface Window {
        SpeechRecognition: { new (): SpeechRecognition };
        webkitSpeechRecognition: { new (): SpeechRecognition };
    }
}

interface ChatScreenProps {
  category: UserCategory;
  age: number;
  gender: UserGender;
  onBack: () => void;
}

const ChatScreen: React.FC<ChatScreenProps> = ({ category, age, gender, onBack }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [attachedFile, setAttachedFile] = useState<{ base64: string; mimeType: string; name: string } | null>(null);
  const [conversationStage, setConversationStage] = useState<ConversationStage>(ConversationStage.INITIAL_QUERY);
  const [isListening, setIsListening] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchVisible, setIsSearchVisible] = useState(false);
  const [isImageSettingsVisible, setIsImageSettingsVisible] = useState(false);
  const [imageStyle, setImageStyle] = useState('Detailed Illustration');
  const [imageAspectRatio, setImageAspectRatio] = useState('4:3');
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        console.warn("Speech recognition not supported in this browser.");
        return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
        setIsListening(true);
        setError(null); // Clear previous errors
    };

    recognition.onend = () => {
        setIsListening(false);
    };

    recognition.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        let errorMessage = `Speech recognition error: ${event.error}`;
        if (event.error === 'not-allowed') {
            errorMessage = "Microphone access denied. Please allow microphone access in your browser settings.";
        } else if (event.error === 'no-speech') {
            errorMessage = "No speech was detected. Please try again.";
        }
        setError(errorMessage);
        setIsListening(false);
    };

    recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(prevInput => prevInput ? `${prevInput.trim()} ${transcript}` : transcript);
    };
    
    recognitionRef.current = recognition;

    return () => {
        if (recognitionRef.current) {
            recognitionRef.current.stop();
        }
    };
}, []);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        setError("File is too large. Please select a file smaller than 10MB.");
        return;
      }
      const reader = new FileReader();
      reader.onload = (loadEvent) => {
        const base64 = (loadEvent.target?.result as string).split(',')[1];
        if (base64) {
          setAttachedFile({ base64, mimeType: file.type, name: file.name });
        }
      };
      reader.onerror = (error) => {
        console.error("FileReader error:", error);
        setError("Failed to read the file.");
      }
      reader.readAsDataURL(file);
    }
    // Reset input value to allow re-selecting the same file
    event.target.value = '';
  };

  const handleSend = async () => {
    if (!input.trim() && !attachedFile) return;
    if (isLoading) return;

    setIsLoading(true);
    setError(null);

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: MessageSender.USER,
      attachment: attachedFile ? {
        dataUrl: `data:${attachedFile.mimeType};base64,${attachedFile.base64}`,
        mimeType: attachedFile.mimeType,
        name: attachedFile.name,
      } : undefined,
    };
    
    const currentInput = input;
    setInput('');
    setAttachedFile(null);

    const aiMessageId = (Date.now() + 1).toString();
    const placeholderAiMessage: Message = {
        id: aiMessageId,
        text: '',
        sender: MessageSender.AI,
    };

    setMessages(prevMessages => [...prevMessages, userMessage, placeholderAiMessage]);
    
    try {
        const stream = generateChatResponseStream(
            currentInput,
            category,
            age,
            gender,
            [...messages, userMessage],
            conversationStage,
            imageStyle
        );

        let visibleText = '';
        let jsonBuffer = '';
        let parsingState: 'PRE_JSON' | 'JSON' | 'TEXT' = 'PRE_JSON';
        const startSeparator = '---JSON_START---';
        const endSeparator = '---JSON_END---';
        let aggregatedSources: GroundingSource[] = [];

        for await (const chunk of stream) {
            if (chunk.candidates?.[0]?.groundingMetadata?.groundingChunks) {
                const newSources = chunk.candidates[0].groundingMetadata.groundingChunks
                    .filter((c): c is { web: { uri: string; title: string } } => 'web' in c && !!c.web?.uri)
                    .map(c => ({ uri: c.web.uri, title: c.web.title || c.web.uri }));
                
                newSources.forEach(ns => {
                    if (!aggregatedSources.some(as => as.uri === ns.uri)) {
                        aggregatedSources.push(ns);
                    }
                });
            }

            let chunkText = chunk.text;
            if (!chunkText) continue;

            if (parsingState === 'PRE_JSON') {
                if (chunkText.includes(startSeparator)) {
                    const parts = chunkText.split(startSeparator);
                    chunkText = parts[1] || '';
                    parsingState = 'JSON';
                } else {
                    // This is a text-only response (e.g., conclusion stage)
                    visibleText += chunkText;
                    setMessages(prev => prev.map(msg => 
                        msg.id === aiMessageId ? { ...msg, text: visibleText } : msg
                    ));
                    continue;
                }
            }

            if (parsingState === 'JSON') {
                if (chunkText.includes(endSeparator)) {
                    const parts = chunkText.split(endSeparator);
                    jsonBuffer += parts[0];
                    const remainingText = parts[1] || '';

                    if (jsonBuffer.trim()) {
                        try {
                            const parsedJson = JSON.parse(jsonBuffer);
                            const finalMedicalTerms = parsedJson.medical_terms?.map((term: any) => ({
                                term: term.term,
                                definition: term.definition,
                            })) || [];
                            const imagePrompt = parsedJson.image_generation_prompt || null;

                            setMessages(prev => prev.map(msg => 
                                msg.id === aiMessageId ? { ...msg, medicalTerms: finalMedicalTerms } : msg
                            ));

                            if (imagePrompt) {
                                generateImageForPrompt(imagePrompt, imageAspectRatio).then(imageBase64 => {
                                    if (imageBase64) {
                                        setMessages(prev => prev.map(msg => 
                                            msg.id === aiMessageId ? { 
                                                ...msg, 
                                                attachment: {
                                                    dataUrl: `data:image/png;base64,${imageBase64}`,
                                                    mimeType: 'image/png',
                                                    name: 'ai-generated-illustration.png'
                                                }
                                            } : msg
                                        ));
                                    }
                                });
                            }
                        } catch (e) {
                            console.error("Failed to parse JSON payload from stream:", e);
                            console.log("Invalid JSON received:", jsonBuffer);
                        }
                    }
                    
                    parsingState = 'TEXT';
                    visibleText += remainingText;
                } else {
                    jsonBuffer += chunkText;
                }
            } else if (parsingState === 'TEXT') {
                visibleText += chunkText;
            }

            if (visibleText) {
                setMessages(prev => prev.map(msg => 
                    msg.id === aiMessageId 
                        ? { ...msg, text: visibleText.trimStart(), sources: aggregatedSources.length > 0 ? aggregatedSources : undefined } 
                        : msg
                ));
            }
        }

        // Final trim after stream is complete
        setMessages(prev => prev.map(msg => 
            msg.id === aiMessageId ? { ...msg, text: msg.text.trim() } : msg
        ));

        if (category === UserCategory.GENERAL) {
            if (conversationStage === ConversationStage.INITIAL_QUERY) {
                setConversationStage(ConversationStage.CLARIFICATION);
            } else if (conversationStage === ConversationStage.CLARIFICATION) {
                setConversationStage(ConversationStage.CONCLUSION);
            } else if (conversationStage === ConversationStage.CONCLUSION) {
                setConversationStage(ConversationStage.INITIAL_QUERY);
            }
        }

    } catch (e) {
        const errorMessage = e instanceof Error ? e.message : 'An unexpected error occurred.';
        setError(errorMessage);
        setMessages(prev => prev.map(msg =>
            msg.id === aiMessageId
                ? { ...msg, text: `Sorry, I encountered an error: ${errorMessage}` }
                : msg
        ));
    } finally {
        setIsLoading(false);
    }
  };


  const handleMicClick = () => {
      if (!recognitionRef.current) {
          setError("Speech recognition is not supported by your browser.");
          return;
      }

      if (isListening) {
          recognitionRef.current.stop();
      } else {
          try {
              recognitionRef.current.start();
          } catch(e) {
              console.error("Could not start speech recognition", e);
          }
      }
  };

  const stageDescription = (): string => {
    if (category !== UserCategory.GENERAL) {
      return `Mode: ${category}`;
    }
    switch(conversationStage) {
      case ConversationStage.INITIAL_QUERY: return "Describe your issue";
      case ConversationStage.CLARIFICATION: return "Answering clarifying questions";
      case ConversationStage.CONCLUSION: return "Receiving conclusion";
      default: return "Chat";
    }
  }

  const filteredMessages = messages.filter(msg =>
    searchQuery ? msg.text.toLowerCase().includes(searchQuery.toLowerCase()) : true
  );

  return (
    <div className="w-full h-full max-w-4xl flex flex-col bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-lg shadow-2xl animate-fade-in-up">
      <header className="flex items-center justify-between p-4 border-b border-slate-700">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm text-slate-300 hover:text-white transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
          Back
        </button>
        <div className="text-center">
            <h2 className="font-semibold text-lg">{category}</h2>
            <p className="text-xs text-slate-400">{age} years old, {gender}</p>
        </div>
        <div className="w-auto flex items-center gap-2">
             <button
                type="button"
                onClick={() => setIsImageSettingsVisible(prev => !prev)}
                title="Image generation settings"
                className="p-1 rounded-full text-slate-300 hover:text-white transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-500"
             >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
             </button>
             <button
                type="button"
                onClick={() => setIsSearchVisible(prev => !prev)}
                title="Search history"
                className="p-1 rounded-full text-slate-300 hover:text-white transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-500"
             >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
             </button>
             <span className="text-xs bg-slate-700 px-2 py-1 rounded-full whitespace-nowrap">{stageDescription()}</span>
        </div>
      </header>

      {isImageSettingsVisible && (
        <div className="p-4 border-b border-slate-700 bg-slate-900/50 animate-fade-in-down">
            <h4 className="text-sm font-semibold text-slate-300 mb-3 text-center">Image Generation Settings</h4>
            <div className="flex flex-col md:flex-row gap-4 justify-center">
                <div>
                    <label htmlFor="imageStyle" className="block text-xs font-medium text-slate-400 mb-1">Illustration Style</label>
                    <select
                        id="imageStyle"
                        value={imageStyle}
                        onChange={(e) => setImageStyle(e.target.value)}
                        className="w-full bg-slate-700 text-slate-200 rounded-md py-1 px-2 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all text-sm"
                    >
                        <option>Detailed Illustration</option>
                        <option>Medical Diagram</option>
                        <option>3D Model</option>
                        <option>Microscopic View</option>
                        <option>X-Ray Style</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="aspectRatio" className="block text-xs font-medium text-slate-400 mb-1">Aspect Ratio</label>
                    <select
                        id="aspectRatio"
                        value={imageAspectRatio}
                        onChange={(e) => setImageAspectRatio(e.target.value)}
                        className="w-full bg-slate-700 text-slate-200 rounded-md py-1 px-2 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all text-sm"
                    >
                        <option value="4:3">Standard (4:3)</option>
                        <option value="16:9">Widescreen (16:9)</option>
                        <option value="1:1">Square (1:1)</option>
                    </select>
                </div>
            </div>
        </div>
      )}

      {isSearchVisible && (
        <div className="p-4 border-b border-slate-700">
            <div className="relative">
                <input
                    type="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search chat history..."
                    className="w-full bg-slate-900 text-slate-200 rounded-lg py-2 pl-10 pr-12 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all"
                    autoFocus
                />
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    title="Clear search"
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-700 transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                  </button>
                )}
            </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && (
          <div className="text-center text-slate-400 mt-8">
            <p>Welcome! How can I help you today?</p>
            <p className="text-sm">For {category === UserCategory.GENERAL ? 'general users' : 'medical students'}.</p>
          </div>
        )}
        {filteredMessages.map((msg, index) => (
          <MessageBubble 
            key={msg.id}
            message={msg} 
            searchQuery={searchQuery}
            isLoading={isLoading && index === filteredMessages.length - 1}
          />
        ))}
        <div ref={messagesEndRef} />
      </div>

      <footer className="p-4 border-t border-slate-700">
        {error && (
            <div className="text-red-400 text-sm mb-2 p-2 bg-red-900/50 border border-red-500 rounded-md">
                <strong>Error:</strong> {error}
            </div>
        )}
        <div className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Type your message... (Shift+Enter for new line)"
            className="w-full bg-slate-700 text-slate-200 rounded-lg py-3 pl-32 pr-28 resize-none focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all"
            rows={1}
            style={{ minHeight: '52px', maxHeight: '200px' }}
            onInput={(e) => {
                const target = e.target as HTMLTextAreaElement;
                target.style.height = 'auto';
                target.style.height = `${target.scrollHeight}px`;
            }}
          />
          <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-3">
            <label htmlFor="file-upload" className="cursor-pointer text-slate-400 hover:text-cyan-400 transition-colors" title="Upload file">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M18.375 12.739l-7.693 7.693a4.5 4.5 0 01-6.364-6.364l10.94-10.94A3 3 0 1119.5 7.372L8.552 18.32m.009-.01l-.01.01m5.699-9.941l-7.81 7.81a1.5 1.5 0 002.122 2.122l7.81-7.81a1.5 1.5 0 00-2.122-2.122z" />
                </svg>
            </label>
            <input id="file-upload" type="file" accept="image/*,application/pdf,.doc,.docx,.txt" className="hidden" onChange={handleFileChange} />
            <label htmlFor="camera-upload" className="cursor-pointer text-slate-400 hover:text-cyan-400 transition-colors" title="Use camera">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
            </label>
            <input id="camera-upload" type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFileChange} />
            <button
              type="button"
              onClick={handleMicClick}
              title={isListening ? "Stop listening" : "Use microphone"}
              className={`p-1 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-500 ${isListening ? 'text-red-500 animate-pulse' : 'text-slate-400 hover:text-cyan-400'}`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M7 11.25v2.25c0 2.485 2.015 4.5 4.5 4.5s4.5-2.015 4.5-4.5V11.25m-9 0V9A4.5 4.5 0 0112 4.5v0A4.5 4.5 0 0116.5 9v2.25m-9 0h9" />
              </svg>
            </button>
          </div>
          <button
            onClick={handleSend}
            disabled={isLoading || (!input.trim() && !attachedFile)}
            className="absolute right-3 top-1/2 -translate-y-1/2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-600 disabled:cursor-not-allowed text-white rounded-md px-4 py-2 flex items-center justify-center gap-2 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-700 focus:ring-cyan-500"
          >
            {isLoading ? <LoadingSpinner /> : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
                </svg>
            )}
            <span>Send</span>
          </button>
        </div>
        {attachedFile && (
            <div className="mt-2 text-sm text-slate-400 flex items-center gap-2 bg-slate-700/50 p-2 rounded-md">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-cyan-400" viewBox="0 0 20 20" fill="currentColor">
                   <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                </svg>
                <span>{attachedFile.name}</span>
                <button onClick={() => setAttachedFile(null)} className="ml-auto text-slate-500 hover:text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                </button>
            </div>
        )}
      </footer>
    </div>
  );
};

export default ChatScreen;