
import React, { useState, useCallback } from 'react';
import LoadingSpinner from './LoadingSpinner';

interface LoginPageProps {
  onLoginSuccess: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const [step, setStep] = useState<'email' | 'otp'>('email');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const MOCK_OTP = '123456'; // The OTP remains the same for the mock flow

  const verifyOtp = useCallback((code: string) => {
    if (isLoading) return;
    setIsLoading(true);
    setError('');
    // Simulate verifying OTP
    setTimeout(() => {
      setIsLoading(false);
      if (code === MOCK_OTP) {
        onLoginSuccess();
      } else {
        setError('Invalid OTP. Please try again.');
      }
    }, 1000);
  }, [onLoginSuccess, isLoading]);


  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/\S+@\S+\.\S+/.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    setError('');
    setIsLoading(true);

    // Simulate sending OTP via email
    setTimeout(() => {
      setIsLoading(false);
      // In a real app, a backend service would send an email with the OTP.
      alert(`For demonstration, your OTP is: ${MOCK_OTP}.\n\nIn a real app, an email would be sent to ${email}.`);
      setStep('otp');
    }, 1500);
  };

  const handleOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    verifyOtp(otp);
  };


  return (
    <div className="w-full max-w-md bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-lg shadow-2xl p-8 animate-fade-in-up">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-100">Welcome Back</h2>
        <p className="text-slate-400 mt-2">Securely login to your ChatDoctor AI account.</p>
      </div>

      {step === 'email' && (
        <form onSubmit={handleEmailSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-2">
              Email Address
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address"
              className="w-full bg-slate-700 text-slate-200 rounded-lg py-3 px-4 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all"
              required
              autoComplete="email"
            />
          </div>
          {error && <p className="text-red-400 text-sm">{error}</p>}
          <button
            type="submit"
            disabled={isLoading || !email}
            className="w-full bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-600 disabled:cursor-not-allowed text-white rounded-md px-4 py-3 flex items-center justify-center gap-2 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-cyan-500 font-semibold"
          >
            {isLoading ? <LoadingSpinner /> : null}
            <span>{isLoading ? 'Sending...' : 'Send OTP'}</span>
          </button>
        </form>
      )}

      {step === 'otp' && (
        <form onSubmit={handleOtpSubmit} className="space-y-6">
          <div>
            <label htmlFor="otp" className="block text-sm font-medium text-slate-300 mb-2">
              Enter OTP
            </label>
            <p className="text-xs text-slate-400 mb-2">An OTP was sent to your email address.</p>
            <input
              type="text"
              id="otp"
              inputMode="numeric"
              value={otp}
              onChange={(e) => setOtp(e.target.value.replace(/[^0-9]/g, ''))}
              placeholder="6-digit code"
              maxLength={6}
              className="w-full bg-slate-700 text-slate-200 rounded-lg py-3 px-4 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all text-center tracking-[0.5em]"
              required
              autoComplete="one-time-code"
            />
          </div>
          {error && <p className="text-red-400 text-sm">{error}</p>}
          <button
            type="submit"
            disabled={isLoading || otp.length !== 6}
            className="w-full bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-600 disabled:cursor-not-allowed text-white rounded-md px-4 py-3 flex items-center justify-center gap-2 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-cyan-500 font-semibold"
          >
            {isLoading ? <LoadingSpinner /> : null}
            <span>{isLoading ? 'Verifying...' : 'Verify & Login'}</span>
          </button>
          <div className="text-center">
            <button
                type="button"
                onClick={() => {
                    setStep('email');
                    setError('');
                    setOtp('');
                }}
                className="text-sm text-slate-400 hover:text-cyan-400 transition-colors"
            >
                Change email address
            </button>
          </div>
        </form>
      )}
      <p className="text-xs text-slate-500 mt-8 text-center">
        <strong className="text-slate-400">Security Notice:</strong> This is a demonstration. In a real application, OTPs would be sent via a secure backend service and not displayed in an alert.
      </p>
    </div>
  );
};

export default LoginPage;
