import React, { useState } from 'react';
import CategorySelector from './components/CategorySelector';
import ChatScreen from './components/ChatScreen';
import { UserCategory, UserGender } from '../types';

const App: React.FC = () => {
  const [userCategory, setUserCategory] = useState<UserCategory | null>(null);
  const [age, setAge] = useState<number | null>(null);
  const [gender, setGender] = useState<UserGender | null>(null);

  const handleSelect = (category: UserCategory, selectedAge: number, selectedGender: UserGender) => {
    setUserCategory(category);
    setAge(selectedAge);
    setGender(selectedGender);
  };

  const handleBack = () => {
    setUserCategory(null);
    setAge(null);
    setGender(null);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center p-6">
      <header className="w-full max-w-4xl text-center mb-8">
        <div className="flex items-center justify-center gap-4">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-cyan-400" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 6 4 4 6.5 4 8.04 4 9.36 4.81 10 6c.64-1.19 1.96-2 3.5-2C17 4 19 6 19 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35zM13 12h3v-2h-3V7h-2v3H8v2h3v3h2v-3z"/>
          </svg>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 text-transparent bg-clip-text">
            ChatDoctor AI
          </h1>
        </div>
        <p className="text-slate-400 mt-2">Your AI medical assistant for clear, accurate information.</p>
      </header>

      <main className="w-full flex-grow flex justify-center">
        {!userCategory || age === null || gender === null ? (
          <CategorySelector onSelect={handleSelect} />
        ) : (
          <ChatScreen category={userCategory} age={age} gender={gender} onBack={handleBack} />
        )}
      </main>
    </div>
  );
};

export default App;
